﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Foundation.DependencyInjection
{
    public enum Lifetime
    {
        Transient,
        Singleton
    }
}